create function pg_catalog.xpath_exists(text, xml) returns boolean
LANGUAGE SQL
AS $$
select pg_catalog.xpath_exists($1, $2, '{}'::pg_catalog.text[])
$$;
